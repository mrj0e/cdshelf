CD Shelf for Lyrion Music Server
Version 0.4.0

The plugin serves the CD Shelf web UI at:
  /plugins/CDShelf/html/index.html

Version 0.4 registers CD Shelf as an LMS app, allowing Material Skin to show it
under Apps and use Material's built-in pin-to-home-screen feature.

The app passes the currently selected LMS player to the shelf page when opened
from LMS/Material.

Version 0.6.0 adds a plugin settings/info page with a direct Open CD Shelf link.
