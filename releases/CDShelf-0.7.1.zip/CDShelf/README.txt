CD Shelf for Lyrion Music Server
Version 0.7.1

The plugin serves the CD Shelf web UI at:
  /plugins/CDShelf/html/index.html

Features include Material Skin app integration, player selection, plugin info page
and a full-width shelf layout.

Attribution
-----------
CD Shelf is based on the “CD Shelf – a custom 3D CD spine browser” shared by
Reddit user ChrisHoppyBot in r/squeezebox. Original concept and code by
ChrisHoppyBot. LMS plugin packaging, Material integration, player selection and
subsequent UI modifications by Joe Leech.

Original post:
https://www.reddit.com/r/squeezebox/comments/1v733oc/share_cd_shelf_a_custom_3d_cd_spine_browser/
